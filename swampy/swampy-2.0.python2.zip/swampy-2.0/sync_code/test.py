mutex = Semaphore(1)
