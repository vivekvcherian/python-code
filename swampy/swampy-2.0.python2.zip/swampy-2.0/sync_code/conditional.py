# mutual exclusion
counter = 0

## Thread code

if counter == 0:
    print True

if counter == 1:
    print False
